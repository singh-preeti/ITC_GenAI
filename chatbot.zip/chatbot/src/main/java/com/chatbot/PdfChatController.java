package com.chatbot;



// import dev.langchain4j.data.document.Document;
// import dev.langchain4j.data.document.loader.pdf.PdfDocumentLoader;
// import dev.langchain4j.data.segment.TextSegment;
// import dev.langchain4j.data.segmenter.TextSegmenter;
// import dev.langchain4j.model.openai.OpenAiChatModel;
// import dev.langchain4j.model.embedding.EmbeddingModel;
// import dev.langchain4j.model.openai.OpenAiEmbeddingModel;
// import dev.langchain4j.store.embedding.EmbeddingStore;
// import dev.langchain4j.store.embedding.inmemory.InMemoryEmbeddingStore;
// import dev.langchain4j.rag.RetrievalAugmentedGenerator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

@Controller
public class PdfChatController {

    @Value("${openai.api.key}")
    private String openAiKey;

    // private EmbeddingStore embeddingStore;
    // private RetrievalAugmentedGenerator rag;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    private String pdfText = null;

    @PostMapping("/upload")
    public String uploadPdf(@RequestParam("file") MultipartFile file, Model model) throws IOException {
        try (InputStream is = file.getInputStream(); PDDocument document = PDDocument.load(is)) {
            PDFTextStripper stripper = new PDFTextStripper();
            pdfText = stripper.getText(document);
            model.addAttribute("message", "PDF uploaded and parsed successfully!");
        } catch (Exception e) {
            model.addAttribute("message", "Failed to parse PDF: " + e.getMessage());
        }
        return "index";
    }

    @PostMapping("/ask")
    public String askQuestion(@RequestParam("question") String question, Model model) {
        model.addAttribute("question", question);
        if (pdfText == null || pdfText.isEmpty()) {
            model.addAttribute("answer", "Please upload a PDF first.");
            return "index";
        }
        String prompt = "Answer the following question based on this PDF content:\n" + pdfText + "\nQuestion: " + question;
        String answer = callOpenAiApi(prompt);
        model.addAttribute("answer", answer);
        return "index";
    }

    private String callOpenAiApi(String prompt) {

    String apiUrl = "https://api.openai.com/v1/chat/completions";

    RestTemplate restTemplate = new RestTemplate();

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setBearerAuth(openAiKey);

    try {
        // Build request JSON
        Map<String, Object> message = new HashMap<>();
        message.put("role", "user");
        message.put("content", prompt);

        Map<String, Object> bodyMap = new HashMap<>();
        bodyMap.put("model", "gpt-4.1-mini");
        bodyMap.put("messages", Collections.singletonList(message));
        bodyMap.put("temperature", 0.2);

        ObjectMapper mapper = new ObjectMapper();
        String body = mapper.writeValueAsString(bodyMap);

        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        ResponseEntity<String> response =
                restTemplate.postForEntity(apiUrl, entity, String.class);

        // Parse JSON safely
        JsonNode root = mapper.readTree(response.getBody());
        JsonNode contentNode =
                root.path("choices").get(0).path("message").path("content");

        return contentNode.asText();

    } catch (Exception e) {
        e.printStackTrace();
        return "Error calling OpenAI API: " + e.getMessage();
    }
}
}
